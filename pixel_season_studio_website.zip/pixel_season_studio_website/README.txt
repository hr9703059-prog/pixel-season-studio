PIXEL SEASON STUDIO WEBSITE

Files:
- index.html: page content and sections
- style.css: responsive black/gold/cream styling
- script.js: mobile navigation, form, enquiry links

HOW TO RUN:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.

BEFORE PUBLISHING:
1. Open script.js.
2. Replace CONFIG.whatsappNumber with your own number in international digits-only format.
   Pakistan example format: 923001234567
3. Replace CONFIG.email with your real business email.
4. Update the contact email shown in index.html.
5. Replace the sample portfolio concepts with your own original work.
6. Confirm prices and service terms with your business partner.

NOTES:
- The enquiry form opens WhatsApp when a valid number is configured.
- The site uses Google Fonts, so fonts may fall back if the visitor is offline.
- This is a static website; it does not include a database or admin dashboard.
