// PIXEL SEASON STUDIO — edit the settings below before publishing.
const CONFIG = {
  // Add your WhatsApp number in international format, digits only.
  // Example format for Pakistan: 923001234567 (do not include + or spaces).
  whatsappNumber: "92XXXXXXXXXX",
  // Replace with your real business email.
  email: "your-email@example.com"
};

const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");

menuToggle.addEventListener("click", () => {
  const isOpen = navMenu.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});

navMenu.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

// Fill enquiry form with a service/package when a visitor clicks a related CTA.
document.querySelectorAll("[data-service]").forEach(link => {
  link.addEventListener("click", () => {
    const select = document.getElementById("serviceChoice");
    const value = link.dataset.service;
    [...select.options].forEach(option => {
      if (option.text === value) select.value = value;
    });
  });
});

document.querySelectorAll("[data-package]").forEach(link => {
  link.addEventListener("click", () => {
    const message = document.getElementById("clientMessage");
    message.value = `I'm interested in: ${link.dataset.package}. Please share the next steps.`;
  });
});

document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("clientName").value.trim();
  const business = document.getElementById("clientBusiness").value.trim();
  const service = document.getElementById("serviceChoice").value;
  const message = document.getElementById("clientMessage").value.trim();

  if (!name || !service || !message) {
    alert("Please fill in your name, service and project details.");
    return;
  }

  const text = [
    "Assalam-o-Alaikum Pixel Season Studio!",
    `Name: ${name}`,
    business ? `Business: ${business}` : "",
    `Service: ${service}`,
    `Project details: ${message}`
  ].filter(Boolean).join("\n");

  if (/^92\d{10}$/.test(CONFIG.whatsappNumber)) {
    const url = `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  } else {
    const subject = encodeURIComponent(`Project enquiry — ${service}`);
    const body = encodeURIComponent(text);
    if (CONFIG.email && CONFIG.email !== "your-email@example.com") {
      window.location.href = `mailto:${CONFIG.email}?subject=${subject}&body=${body}`;
    } else {
      alert("Before using the enquiry form, open script.js and add your WhatsApp number (international format) or real email address.");
    }
  }
});

// Subtle reveal effects; content stays visible if reduced motion is preferred.
const revealTargets = document.querySelectorAll(
  ".service-card, .portfolio-item, .price-card, .about-stamp, .contact-form"
);
if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  revealTargets.forEach(el => el.classList.add("reveal"));
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealTargets.forEach(el => observer.observe(el));
}
